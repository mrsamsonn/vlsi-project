main magic file is 4bit-sub.mag, the rest are its parts

testing:
file-name= 4bit-sub.cmd
parameters= A B Y