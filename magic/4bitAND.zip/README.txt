project.cmd is for 2AND
4bitAND.cmd is for 4bitAND